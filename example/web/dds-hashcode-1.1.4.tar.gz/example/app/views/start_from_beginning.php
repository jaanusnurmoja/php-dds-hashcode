<p>
    <a href="">Start from the beginning</a>
</p>
<p id="success" style="display: none;" class="alert alert-success"></p>