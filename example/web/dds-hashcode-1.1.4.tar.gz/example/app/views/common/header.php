<html lang="en">
<head>
    <meta http-equiv="x-ua-compatible" content="IE=Edge"/>
    <meta charset="UTF-8">
    <!-- Third party CSS libs -->
    <link rel="stylesheet" href="assets/css/external/bootstrap.css">

    <!-- Sample application CSS  -->
    <link rel="stylesheet" href="assets/css/custom.css">

    <!-- Third party JS libs -->
    <script src="assets/js/external/jquery.js"></script>
    <script src="assets/js/external/bootstrap.js"></script>
    <script src="assets/js/external/npo.js"></script>
    <script src="assets/js/external/hwcrypto.js"></script>

    <!-- Sample application JS -->
    <script src="assets/js/hashcode.js"></script>
    <title>DDS Hashcode example PHP webapp</title>
</head>
<body>

<div id="container">
    <div class="row header-row">
        <div class="col-sm-11">
            <div class="col-sm-1">
                <a href="http://www.sk.ee/"><img src="assets/images/sklogo.GIF" style="border: 0;"></a>
            </div>
            <h2 id="title-text">
                DDS HASHCODE EXAMPLE PHP WEB APPLICATION
            </h2>
        </div>
    </div>

    <div class="row content">
