<?php
namespace SK\Digidoc\Example\Helpers;

/**
 * Class MobileIDException
 *
 * @package SK\Digidoc\Example\Helpers
 */
class MobileIDException extends \Exception
{

}