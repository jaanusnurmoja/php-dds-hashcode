<?php
namespace SK\Digidoc\Example\Helpers;

/**
 * Class FileException
 *
 * @package SK\Digidoc\Example\Helpers
 */
class FileException extends \Exception
{

}
