<?php
/**
 * Created by PhpStorm.
 * User: MihkelNortal
 * Date: 11/20/15
 * Time: 1:55 PM
 */

namespace SK\Digidoc\Example\Exception;

class SoapClientException extends \Exception
{

}