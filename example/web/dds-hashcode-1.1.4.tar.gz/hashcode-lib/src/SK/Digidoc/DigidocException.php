<?php
namespace SK\Digidoc;

/**
 * General exception for dds-hashcode library.
 */
class DigidocException extends \Exception
{
}
